package com.example.newsapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class NewsListAdapter( private val listener:NewsItemClicked): RecyclerView.Adapter<NewsViewHolder>() {

    private val item: ArrayList<News> = ArrayList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NewsViewHolder {

        val view = LayoutInflater.from(parent.context).inflate(R.layout.news_view_recview,parent,false)
        val viewHolder = NewsViewHolder(view)
        view.setOnClickListener{
            listener.onItemClicked(item[viewHolder.adapterPosition])
        }
        return viewHolder

    }

    override fun onBindViewHolder(holder: NewsViewHolder, position: Int) {

        val currentItem = item[position]
        holder.headlinetxt.text = currentItem.title
//        holder.headlineimg.setImageResource(R.id.browser_actions_menu_item_icon)

    }

    override fun getItemCount(): Int {
    return item.size
    }
    fun updateNews(updatedNews: ArrayList<News>){
        item.clear()
        item.addAll(updatedNews)

        notifyDataSetChanged()
    }
}

class NewsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    val headlinetxt: TextView = itemView.findViewById(R.id.headlineOfNews)
    val headlineimg: ImageView = itemView.findViewById(R.id.imageOfNews)

}
interface NewsItemClicked{
    fun onItemClicked(item:News)
}