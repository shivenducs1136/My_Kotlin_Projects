package com.example.newsapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.example.newsapp.databinding.FragmentProfileBinding
import com.google.firebase.auth.FirebaseAuth

class ProfileFragment : Fragment() {

    lateinit var binding: FragmentProfileBinding
    lateinit var navController: NavController

    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = DataBindingUtil.inflate(inflater,R.layout.fragment_profile, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navController = Navigation.findNavController(view)
        binding.heartrot.animate().apply {
            duration = 100000
            rotationYBy(360f)
        }.start()

            //inti firebase
        firebaseAuth = FirebaseAuth.getInstance()
        checkUser()

        // handle click logout
        binding.logoutbutton.setOnClickListener{
            firebaseAuth.signOut()
            Toast.makeText(context,"Logged Out please Login / Register",Toast.LENGTH_LONG).show()
            checkUser()
        }

    }

    private fun checkUser() {
        val firebaseUser = firebaseAuth.currentUser
        if(firebaseUser!=null){
            // user not null , user is logged in
            val email = firebaseUser.email
            // set to text view
            binding.nametxtview.text = email

        }
        else{
            // user is null , go to loginn fragment
            navController.navigate(R.id.loginFragment)

        }
    }

}