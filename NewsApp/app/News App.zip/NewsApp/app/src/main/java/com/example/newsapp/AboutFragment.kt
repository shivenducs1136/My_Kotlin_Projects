package com.example.newsapp

import androidx.fragment.app.Fragment

class AboutFragment : Fragment(R.layout.fragment_about){



}